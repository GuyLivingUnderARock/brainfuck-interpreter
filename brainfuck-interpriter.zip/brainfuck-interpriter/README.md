To Use Just Make A .bf File In The Same Directory As The Python File, Run run.bat, Then Follow The On Screen Instructions.
Even An Idiot Can Use It.