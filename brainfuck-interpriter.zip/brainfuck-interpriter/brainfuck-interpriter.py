import glob
import os


def GetFiles():
    fileName = ''
    x = __file__.split('/')
    x.pop(len(x)-1)
    for section in x: fileName += section + '\\'

    files = []
    temp = []

    for f in glob.glob(fileName + '*.bf'):
        filename = f.split('\\')

        for section in filename:
            if filename.index(section) == len(filename)-1: temp.append(section)
    
    for f in temp: files.append(f.split('.')[0])

    return files, fileName

def run(code):
    pointer = 0
    cells = [0]

    i = 0
    loops = []
    while i < len(code):
        char = code[i]
        if char == '+':
            if cells[pointer] >= 255: cells[pointer] = 0
            else: cells[pointer] += 1

        elif char == '-':
            if cells[pointer] <= 0: cells[pointer] = 255
            else: cells[pointer] -= 1

        elif char == '>':
            if not pointer >= len(cells)-1: pointer += 1
            else:
                cells.append(0)
                pointer += 1

        elif char == '<':
            if not pointer <= 0: pointer -= 1

        elif char == '[':
            loops.append(i)

        elif char == ']':
            if cells[pointer] == 0:
                loops.pop()
            else:
                i = loops[len(loops)-1]

        elif char == ',':
            cells[pointer] = ord(input())

        elif char == '.':
            print(chr(cells[pointer]))
        i+=1

        try:
            cellsMemoryFile = open(fileName+'cells-memory.txt', 'x')
        except FileExistsError:
            cellsMemoryFile = open(fileName+'cells-memory.txt', 'w')

        cellsMemoryFile.write(str(cells))


while True:
    fileName = GetFiles()[1]
    files = GetFiles()[0]

    print('Avaliable brainfuck Files:', end=' ')

    for f in files:
        if files.index(f) == len(files) - 1: print(f, end='.\n')
        else: print(f, end=', ')
        
    fileToUse = input('Please Select A File To Use, Or Quit(quit/q): ')

    if fileToUse.lower() == 'quit' or fileToUse.lower() == 'q': break

    for f in files:
        if fileToUse == f:
            openFile = open(fileName + fileToUse + '.bf', 'r').read()
            print()

    run(openFile)

try: cellsMemoryFile.close()
except NameError: pass
